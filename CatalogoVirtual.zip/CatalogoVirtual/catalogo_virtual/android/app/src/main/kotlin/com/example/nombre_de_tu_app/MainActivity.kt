package com.example.nombre_de_tu_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
